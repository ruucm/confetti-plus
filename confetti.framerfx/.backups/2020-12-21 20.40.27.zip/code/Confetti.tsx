import * as React from "react"
import { useRef, useEffect } from "react"
import { Particle } from "./particle"
// import { Circle } from "./circle"
import { addPropertyControls, ControlType } from "framer"

const totalParticles = 30
const particles = []

export function Confetti(props) {
  const canvasRef = useRef(null)
  const { particleColors, ...options } = props
  init()

  function init() {
    for (let i = 0; i < totalParticles; i++) {
      // const image = new Image()
      // image.src = this.imgItem[getRandomInt(0, this.imgItem.length)]
      const item = new Particle(
        randomRange(40, 100),
        particleColors[getRandomInt(0, particleColors.length)],
        // randomRange(100, 300),
        // randomRange(100, 300)
        options
      )
      particles[i] = item
    }
    console.log("particles", particles)
  }

  useEffect(() => {
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")
    let frameCount = 0
    let animationFrameId

    //Our draw came here
    const render = () => {
      frameCount++
      // draw(context, frameCount)
      context.clearRect(0, 0, context.canvas.width, context.canvas.height)
      for (let i = 0; i < totalParticles; i++) {
        const item = particles[i]
        item.draw(context, frameCount)
      }
      animationFrameId = window.requestAnimationFrame(render)
    }
    render()

    return () => {
      window.cancelAnimationFrame(animationFrameId)
    }
  }, [])

  return <canvas ref={canvasRef} {...props} />
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}

function randomRange(min, max) {
  return Math.random() * (max - min) + min
}

Confetti.defaultProps = {
  width: 300,
  height: 600,
}

addPropertyControls(Confetti, {
  x: {
    type: ControlType.Number,
    defaultValue: 150,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
  },
  y: {
    type: ControlType.Number,
    defaultValue: 0,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
  },
  velocity: {
    type: ControlType.Number,
    defaultValue: 5,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
  },
  gravity: {
    type: ControlType.Number,
    defaultValue: 0,
    min: 0,
    max: 1000,
    unit: "px/frame",
    step: 0.01,
    displayStepper: true,
  },
  launchDegree: {
    type: ControlType.Number,
    defaultValue: -90,
    min: -360,
    max: 360,
    unit: "deg",
    step: 5,
    displayStepper: true,
  },
  injectionDegree: {
    type: ControlType.Number,
    defaultValue: 90,
    min: -360,
    max: 360,
    unit: "deg",
    step: 5,
    displayStepper: true,
  },
  particleColors: {
    type: ControlType.Array,
    propertyControl: {
      type: ControlType.Color,
    },
    defaultValue: [
      "#1abc9c",
      "#2ecc71",
      "#f1c40f",
      "#e74c3c",
      "#c0392b",
      "#27ae60",
      "#9b59b6",
    ],
  },
})
