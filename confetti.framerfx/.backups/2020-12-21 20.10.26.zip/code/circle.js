export class Circle {
  constructor(radius, color, x, y) {
    this.radius = radius
    this.color = color
    this.x = x
    this.y = y
    this.vx = 1
  }

  draw(ctx, frameCount) {
    this.x += this.vx

    // ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height)
    ctx.fillStyle = this.color
    ctx.beginPath()
    ctx.arc(this.x, this.y, this.radius * 2, 0, 2 * Math.PI)
    ctx.fill()
  }
}
