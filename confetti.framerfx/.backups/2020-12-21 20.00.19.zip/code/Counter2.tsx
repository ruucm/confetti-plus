import * as React from "react"
import { Particle } from "./particle"

const particles = []
const totalParticles = 2
const colorPalette = [
  "#1abc9c",
  "#2ecc71",
  "#f1c40f",
  "#e74c3c",
  "#c0392b",
  "#27ae60",
  "#9b59b6",
]

export const Counter2 = () => {
  const [count, setCount] = React.useState(0)

  // Use useRef for mutable variables that we want to persist
  // without triggering a re-render on their change
  const requestRef = React.useRef()
  const previousTimeRef = React.useRef()
  const canvasRef = React.useRef(null)

  for (let i = 0; i < totalParticles; i++) {
    // const image = new Image()
    // image.src = this.imgItem[getRandomInt(0, this.imgItem.length)]
    const item = new Particle(
      Math.random() * 60,
      colorPalette[getRandomInt(0, colorPalette.length)],
      "🎉"
    )
    particles[i] = item
  }
  console.log("particles", particles)

  const animate = (time, ctx) => {
    if (previousTimeRef.current != undefined) {
      const deltaTime = time - previousTimeRef.current
      // console.log("ctx", ctx)
      // item.draw(ctx)

      // Pass on a function to the setter of the state
      // to make sure we always have the latest state
      // setCount((prevCount) => (prevCount + deltaTime * 0.01) % 100)
    }
    previousTimeRef.current = time
    requestRef.current = requestAnimationFrame((t) => animate(t, ctx))
    for (let i = 0; i < totalParticles; i++) {
      const item = particles[i]
      item.draw(ctx)
    }
  }

  React.useEffect(() => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d")
      requestRef.current = requestAnimationFrame((t) => animate(t, ctx))
    }

    return () => cancelAnimationFrame(requestRef.current)
  }, [canvasRef]) // Make sure the effect runs only once

  return (
    <>
      <canvas
        ref={canvasRef}
        width="300px"
        style={{
          background: "pink",
        }}
      >
        Confetti
      </canvas>
      <div
        style={{
          fontSize: 100,
          fontWeight: 900,
        }}
      >
        {Math.round(count)}
      </div>
    </>
  )
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}
