import * as React from "react";


export function Confetti() {




  
  
  return <canvas>Confetti</canvas>;
}

Confetti.defaultProps = {};
