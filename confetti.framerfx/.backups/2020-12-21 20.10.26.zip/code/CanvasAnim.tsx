import * as React from "react"
import { useRef, useEffect } from "react"
import { Particle } from "./particle"
// import { Circle } from "./circle"

const totalParticles = 2
const colorPalette = [
  "#1abc9c",
  "#2ecc71",
  "#f1c40f",
  "#e74c3c",
  "#c0392b",
  "#27ae60",
  "#9b59b6",
]
const particles = []

export function CanvasAnim(props) {
  const canvasRef = useRef(null)
  init()

  function init() {
    for (let i = 0; i < totalParticles; i++) {
      // const image = new Image()
      // image.src = this.imgItem[getRandomInt(0, this.imgItem.length)]
      const item = new Particle(
        randomRange(40, 100),
        colorPalette[getRandomInt(0, colorPalette.length)],
        randomRange(100, 300),
        randomRange(100, 300)
      )
      particles[i] = item
    }
    console.log("particles", particles)
  }

  useEffect(() => {
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")
    let frameCount = 0
    let animationFrameId

    //Our draw came here
    const render = () => {
      frameCount++
      // draw(context, frameCount)
      context.clearRect(0, 0, context.canvas.width, context.canvas.height)
      for (let i = 0; i < totalParticles; i++) {
        const item = particles[i]
        item.draw(context, frameCount)
      }
      animationFrameId = window.requestAnimationFrame(render)
    }
    render()

    return () => {
      window.cancelAnimationFrame(animationFrameId)
    }
  }, [])

  return <canvas ref={canvasRef} {...props} />
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}

function randomRange(min, max) {
  return Math.random() * (max - min) + min
}
