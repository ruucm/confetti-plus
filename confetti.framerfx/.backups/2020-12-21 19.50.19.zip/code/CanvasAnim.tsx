import * as React from "react"
import { useRef, useEffect } from "react"
import { Particle } from "./particle"

const totalParticles = 1
const colorPalette = [
  "#1abc9c",
  "#2ecc71",
  "#f1c40f",
  "#e74c3c",
  "#c0392b",
  "#27ae60",
  "#9b59b6",
]

export function CanvasAnim(props) {
  const canvasRef = useRef(null)

  const draw = (ctx, frameCount) => {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height)
    ctx.fillStyle = "#000000"
    ctx.beginPath()
    ctx.arc(0, 0, 100 * Math.sin(frameCount * 0.05) ** 2, 0, 2 * Math.PI)
    ctx.fill()
  }

  useEffect(() => {
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")
    let frameCount = 0
    let animationFrameId

    //Our draw came here
    const render = () => {
      frameCount++
      draw(context, frameCount)
      animationFrameId = window.requestAnimationFrame(render)
    }
    render()

    return () => {
      window.cancelAnimationFrame(animationFrameId)
    }
  }, [draw])

  return <canvas ref={canvasRef} {...props} />
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}
