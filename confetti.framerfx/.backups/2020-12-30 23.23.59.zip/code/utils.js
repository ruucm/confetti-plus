export function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}

export function randomRange(min, max) {
  return Math.random() * (max - min) + min
}
