import * as React from "react"
import { useRef, useEffect } from "react"
import { Particle } from "./particle"
import { addPropertyControls, ControlType } from "framer"

const particles = []

export function Confetti(props) {
  const canvasRef = useRef(null)
  const { particleNumber, particleColors, emojis, ...options } = props
  init()

  function init() {
    
    for (let i = 0; i < particleNumber; i++) {
      // const image = new Image()
      // image.src = this.imgItem[getRandomInt(0, this.imgItem.length)]
      const item = new Particle( 
        particleColors[getRandomInt(0, particleColors.length)],
        emojis[getRandomInt(0,emojis.length)],
        options
      )
      particles[i] = item
    }
    // console.log("particles", particles)
  }

  useEffect(() => {
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")
    let frameCount = 0
    let animationFrameId

    //Our draw came here
    const render = () => {
      frameCount++
      context.clearRect(0, 0, context.canvas.width, context.canvas.height)
      for (let i = 0; i < particleNumber; i++) {
        const item = particles[i]
        item.draw(context, frameCount)
      }
      animationFrameId = window.requestAnimationFrame(render)
    }
    render()

    return () => {
      window.cancelAnimationFrame(animationFrameId)
    }
  }, [])

  return <canvas ref={canvasRef} {...props} />
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}

function randomRange(min, max) {
  return Math.random() * (max - min) + min
}

Confetti.defaultProps = {
  width: 300,
  height: 600,
}


addPropertyControls(Confetti, {
  particleNumber: {
    type: ControlType.Number,
    defaultValue: 50,
    min: 0,
    max: 1000,
    step: 5,
    displayStepper: true,
  },
  type: {
    type: ControlType.SegmentedEnum,
    options: ["shape", "emoji", "image"],
    optionTitles: ["Shape", "Emoji", "Image"],

  },
  shape: {
    type: ControlType.SegmentedEnum,
    options:["rect", "circle", "star"],
    optionTitles: ["■", "●", "★"],
    hidden(props) {
      return props.type !== "shape"
    },
  },
  particleWidth: {
    type: ControlType.Number,
    defaultValue: 20,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
    hidden(props) {
      return props.type !== "shape" || props.shape !== "rect"
    },
  },
  particleHeight: {
    type: ControlType.Number,
    defaultValue: 15,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
    hidden(props) {
      return props.type !== "shape" || props.shape !== "rect"
    },
  },
  particleSize: {
    type: ControlType.Number,
    defaultValue: 30,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
    hidden(props) {
      return  props.shape !== "circle" 
    },
  },
  x: {
    type: ControlType.Number,
    defaultValue: 100,
    min: 0,
    max: 500,
    unit: "px",
    step: 5,
    displayStepper: true,
  },
  y: {
    type: ControlType.Number,
    defaultValue: 0,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
  },
  velocity: {
    type: ControlType.Number,
    defaultValue: 10,
    min: 0,
    max: 1000,
    unit: "px",
    step: 5,
    displayStepper: true,
  },
  friction: {
    type: ControlType.Number,
    defaultValue: 0.7,
    min: 0,
    max: 1,
    step: 0.1,
    displayStepper: true,
  },
  gravity: {
    type: ControlType.Number,
    defaultValue: 0.02,
    min: 0,
    max: 1000,
    step: 0.01,
    displayStepper: true,
  },
  launchDegree: {
    type: ControlType.Number,
    defaultValue: -90,
    min: -360,
    max: 360,
    unit: "deg",
    step: 90,
    displayStepper: true,
  },
  injectionDegree: {
    type: ControlType.Number,
    defaultValue: 120,
    min: -360,
    max: 360,
    unit: "deg",
    step: 5,
    displayStepper: true,
  },
  wind: {
    type: ControlType.Number,
    defaultValue: 0,
    min: -10,
    max: 10,
    step: 0.1,
    displayStepper: true,
  },
  particleColors: {
    type: ControlType.Array,
    propertyControl: {
      type: ControlType.Color,
    },
    defaultValue: [
      "#1abc9c",
      "#2ecc71",
      "#f1c40f",
      "#e74c3c",
      "#c0392b",
      "#27ae60",
      "#9b59b6",
    ],
    hidden(props) {
      return props.type !== "shape"
    },
  },
  emojis: {
    type: ControlType.Array,
    propertyControl: {
      type: ControlType.String,
    },
    defaultValue: [
      "🎉",
      "🤡",
      "🎄",
    ],
    hidden(props) {
      return props.type !== "emoji"
    },
  },
})