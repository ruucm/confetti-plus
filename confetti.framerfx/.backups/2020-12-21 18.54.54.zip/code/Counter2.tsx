import * as React from "react"

export const Counter2 = () => {
  const [count, setCount] = React.useState(0)

  // Use useRef for mutable variables that we want to persist
  // without triggering a re-render on their change
  const requestRef = React.useRef()
  const previousTimeRef = React.useRef()
  const canvasRef = React.useRef(null)

  const animate = (time, item, ctx) => {
    if (previousTimeRef.current != undefined) {
      const deltaTime = time - previousTimeRef.current
      console.log("ctx", ctx)

      // Pass on a function to the setter of the state
      // to make sure we always have the latest state
      setCount((prevCount) => (prevCount + deltaTime * 0.01) % 100)
    }
    previousTimeRef.current = time
    requestRef.current = requestAnimationFrame(() => animate(time, item, ctx))
  }

  React.useEffect(() => {
    if (canvasRef.current) {
      const item = new Particle(Math.random() * 60, "#e74c3c", "🎉")
      requestRef.current = requestAnimationFrame((t) =>
        animate(t, item, canvasRef.current.getContext("2d"))
      )
    }

    return () => cancelAnimationFrame(requestRef.current)
  }, [canvasRef]) // Make sure the effect runs only once

  return <canvas ref={canvasRef}>Confetti</canvas>
}
