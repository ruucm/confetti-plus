import * as React from "react"
import { useRef, useEffect } from "react"
import { Particle } from "./particle"

export function Confetti() {
  console.log("Particle", Particle)
  const ref = useRef(null)

  useEffect(() => {
    if (ref.current) {
      const item = new Particle(Math.random() * 60, "#e74c3c", "🎉")
      const ctx = ref.current.getContext("2d")
      console.log("item", item)

      animate(item, ctx)
    }
  }, [ref])

  function animate(item, ctx) {
    // console.log("animate")
    // requestAnimationFrame(() => animate(item, ctx))

    item.draw(ctx)
  }

  return <canvas ref={ref}>Confetti</canvas>
}

Confetti.defaultProps = {}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}
