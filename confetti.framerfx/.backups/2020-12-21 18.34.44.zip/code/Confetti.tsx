import * as React from "react"
import { useRef, useEffect } from "react"
import { Particle } from "./particle"

export function Confetti() {
  console.log("Particle", Particle)
  const ref = useRef(null)

  useEffect(() => {
    if (ref.current) {
      const item = new Particle(Math.random() * 60, "#e74c3c", "🎉")
      const ctx = ref.current
      console.log("item", item)

      requestAnimationFrame(() => update(item, ctx))
    }
  }, [ref])

  function update(item, ctx) {
    item.draw(ctx)
  }

  return <canvas ref={ref}>Confetti</canvas>
}

Confetti.defaultProps = {}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}
